# HPOS Build Progress Log

This file is the shared checkpoint for the HPOS prompt series. Every prompt reads this file first and appends to it last. Do not skip ahead if an earlier prompt isn't marked `done` — later prompts assume earlier configuration exists.

**How to read this file:** each entry below corresponds to one prompt in the series (`00_environment_foundation.md` through `12_fixtures_deploy_prep.md`). Status is one of: `not started`, `in progress`, `done`, `blocked`.

---

## Environment
- Site name: _(fill in once created)_
- Frappe branch: version-15
- ERPNext version: _(fill in)_
- India Compliance app version: _(fill in)_
- Local bench path: _(fill in)_

## Prompt Log

### 00 — Environment & Foundation
- Status: not started
- Notes:
- Verification result:

### 01 — Selling
- Status: not started
- Notes:
- Verification result:

### 02 — Buying
- Status: not started
- Notes:
- Verification result:

### 03 — Stock & Items
- Status: not started
- Notes:
- Verification result:

### 04 — Manufacturing
- Status: not started
- Notes:
- Verification result:

### 05 — Quality Management
- Status: not started
- Notes:
- Verification result:

### 06 — Packing & Dispatch
- Status: not started
- Notes:
- Verification result:

### 07 — Accounts & GST
- Status: not started
- Notes:
- Verification result:

### 08 — Roles & Permissions
- Status: not started
- Notes:
- Verification result:

### 09 — hpos_extensions Scaffold + Order Timeline
- Status: not started
- Notes:
- Verification result:

### 10 — Founder Dashboard
- Status: not started
- Notes:
- Verification result:

### 11 — QR Dispatch Scan
- Status: not started
- Notes:
- Verification result:

### 12 — Fixtures Export + Deploy Prep
- Status: not started
- Notes:
- Verification result:

---

## Known Open Items Carried Forward
(Copied from the spec docs — resolve with the client before production go-live, not before dev/config work.)
- Company legal name, address(es), GSTIN(s), plant location(s), financial year start, default currency, logo, brand color
- Chart of Accounts / current accounting software (Tally?) / ERPNext-as-primary vs. alongside Tally
- Customer master, supplier master, item master, BOMs
- Data migration scope (opening balances vs. full masters vs. historical transactions)
- Barcode/QR hardware for dispatch scanning (dedicated scanner vs. phone/tablet camera)
- Go-live timeline and blackout periods
- Domain name, business email/SMTP details
